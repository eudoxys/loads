"""Test TSGAM"""

import os
import datetime as dt
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import tsgam_estimator as tsgam

if __name__ == "__main__":

    pd.options.display.width = None
    pd.options.display.max_columns = None
    pd.options.display.max_rows = 100

    state = "CA"
    county = "Los Angeles"

    test_file = f"tsgam_test-{county}-{state}.csv"
    if not os.path.exists(test_file): # only possible if loads module is installed
        from loads import Total
        data = Total(state,county)
        data.to_csv(test_file,index=True,header=True)
    else:
        data = pd.read_csv(test_file,index_col=0,parse_dates=True)

    # holdout the last 7 days of each month in the timeseries for testing
    holdout = data.index[data.index.month != (data.index+dt.timedelta(days=7)).month]
    training = data.index[data.index.month == (data.index+dt.timedelta(days=7)).month]

    # run test
    TSGAM_CONFIG = tsgam.TsgamEstimatorConfig(
        multi_periodic_config=tsgam.TsgamMultiPeriodicConfig(
            num_harmonics=[6, 4, 3],
            periods=[365.2425 * 24, 7 * 24, 24]
        ),
        exog_config=[tsgam.TsgamSplineConfig(
                    knots=[],  # Empty list means knots will be auto-generated from data
                    n_knots=10,  # Number of knots to generate
                    lags=[-3, -2, -1, 0, 1, 2, 3],
                    reg_weight=1e-4,  # Regularization weight for coefficients
                    diff_reg_weight=1.0  # Regularization weight for differences between lags
                )],
        ar_config=tsgam.TsgamArConfig(
            lags = list(range(1,36))
            ),
        solver_config=tsgam.TsgamSolverConfig(
            solver='CLARABEL',
            verbose=False
        ),
        random_state=None,
        debug=False
        )

    # test = data.test(state,county,holdout,Y="elec_total_MW").rename({"elec_total_MW": "holdout"},axis=1)
    estimator = tsgam.TsgamEstimator(config=TSGAM_CONFIG)
    estimator.fit(data.loc[training].temperature_degF.to_frame(),np.log(data.loc[training].elec_total_MW))

    test = data[["temperature_degF","elec_total_MW"]].copy()
    test["predict"] = np.exp(estimator.predict(data.temperature_degF.to_frame()))
    test["sample"] = np.exp(estimator.sample(data.temperature_degF.to_frame()))[0]

    test["training"] = test.elec_total_MW
    test.loc[holdout,"training"] = float('nan')

    test["holdout"] = test.elec_total_MW
    test.loc[training,"holdout"] = float('nan')

    residual = test["predict"] - test["holdout"]
    rmse = np.sqrt(np.mean(residual**2))
    mean = test["holdout"].mean()
    rmse_percent = rmse / mean * 100 if mean != 0 else (0 if rmse == 0 else np.inf)

    plot_range = pd.date_range("2018-01-25 00:00:00+0000","2018-02-01 00:00:00+0000",freq="1h")
    test.loc[plot_range,["training","predict","sample","holdout"]].plot(
        figsize=(20,10),
        color=["r","b","y","k"],
        title=f"{county} {state} (RMSE={rmse_percent:.2f}%)",
        xlabel="Date/Time",
        ylabel="Load (MW)",
        grid=True,
        )
    plt.show()
