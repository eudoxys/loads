import marimo

__generated_with = "0.20.2"
app = marimo.App(width="medium")


@app.cell
def _():
    import marimo as mo
    import os
    import datetime as dt
    import pandas as pd
    import numpy as np
    import matplotlib.pyplot as plt
    import seaborn as sns
    import tsgam_estimator as tsgam

    return dt, mo, np, pd, plt, sns, tsgam


@app.cell
def _(np):
    rms = lambda _x: np.sqrt(np.nanmean(np.square(_x)))
    return (rms,)


@app.cell
def _():
    state = "CA"
    county = "Los Angeles"
    return county, state


@app.cell
def _(county, pd, state):
    test_file = f"tsgam_test-{county}-{state}.csv"
    data = pd.read_csv(test_file,index_col=0,parse_dates=True)
    return (data,)


@app.cell
def _(data, dt):
    holdout = data.index[data.index.month != (data.index+dt.timedelta(days=7)).month]
    training = data.index[data.index.month == (data.index+dt.timedelta(days=7)).month]
    return holdout, training


@app.cell
def _(data):
    data
    return


@app.cell
def _(data, mo):
    col_slct = mo.ui.dropdown(options=data.columns, value='temperature_degF', label='select column to plot')
    col_slct
    return (col_slct,)


@app.cell
def _(col_slct, data):
    data.plot(x=col_slct.value, y='elec_total_MW', marker='.', linewidth=.1)
    return


@app.cell
def _(data, sns):
    sns.heatmap(data['elec_total_MW'].values.reshape((24, -1), order='F'), cmap='plasma')
    return


@app.cell
def _(data, sns):
    sns.heatmap(data['temperature_degF'].values.reshape((24, -1), order='F'), cmap='plasma')
    return


@app.cell
def _(np, process, scale):
    if process.value == 'max-scale':
        forward = lambda _x: _x / scale
        reverse = lambda _x: scale * _x
    elif process.value == 'log':
        forward = lambda _x: np.log(_x)
        reverse = lambda _x: np.exp(_x)
    return forward, reverse


@app.cell
def _(mo):
    process = mo.ui.dropdown(options=['max-scale', 'log'], value='max-scale', label='preprocessing:')
    process
    return (process,)


@app.cell
def _(np, tsgam):
    lags = 7
    TSGAM_CONFIG = tsgam.TsgamEstimatorConfig(
        multi_periodic_config=tsgam.TsgamMultiPeriodicConfig(
            # num_harmonics=[6, 4, 3],
            num_harmonics=[3, 3, 16],
            periods=[365.2425 * 24, 7 * 24, 24]
        ),
        # exog_config=[tsgam.TsgamSplineConfig(
        #             knots=[],  # Empty list means knots will be auto-generated from data
        #             # n_knots=10,
        #             n_knots=8,  # Number of knots to generate
        #             # lags=[-3, -2, -1, 0, 1, 2, 3],
        #             lags=list(np.arange(2 * lags + 1) - lags),
        #             reg_weight=1e-4,  # Regularization weight for coefficients
        #             diff_reg_weight=0.5  # Regularization weight for differences between lags
        #         )],
        exog_config=[
            tsgam.TsgamSplineConfig(
                    knots=[],  # Empty list means knots will be auto-generated from data
                    n_knots=8,  # Number of knots to generate
                    # lags=[-3, -2, -1, 0, 1, 2, 3],
                    lags=list(np.arange(2 * lags + 1) - lags),
                    reg_weight=1e-4,  # Regularization weight for coefficients
                    diff_reg_weight=0.5  # Regularization weight for differences between lags
                ),
            tsgam.TsgamSplineConfig(
                    knots=[],  # Empty list means knots will be auto-generated from data
                    n_knots=8,  # Number of knots to generate
                    # lags=[-1, 0, 1],
                    lags=list(np.arange(2 * lags + 1) - lags),
                    reg_weight=1e-4,  # Regularization weight for coefficients
                    diff_reg_weight=0.5  # Regularization weight for differences between lags
                )
        ],
        ar_config=tsgam.TsgamArConfig(
            lags = list(range(1,36))
            ),
        solver_config=tsgam.TsgamSolverConfig(
            solver='CLARABEL',
            verbose=True
        ),
        random_state=None,
        debug=False
        )
    return (TSGAM_CONFIG,)


@app.cell
def _(plt, rms, test_error, training_error):
    plt.hist(training_error, label=f'train error, rmse={rms(training_error):.3f}', bins=100, alpha=0.7)
    plt.hist(test_error, label=f'test error, rmse={rms(test_error):.3f}', bins=25, alpha=0.7)
    plt.legend()
    plt.gcf()
    return


@app.cell
def _(data, np, training):
    scale = np.nanmax(data.loc[training].elec_total_MW)
    return (scale,)


@app.cell
def _(TSGAM_CONFIG, data, forward, training, tsgam):
    estimator = tsgam.TsgamEstimator(config=TSGAM_CONFIG)
    estimator.fit(
        X=data.loc[training, ["temperature_degF", "humidity_pc"]],
        y=forward(data.loc[training].elec_total_MW)
    )
    None
    return (estimator,)


@app.cell
def _(data, estimator):
    predicted = estimator.predict(X=data[["temperature_degF", "humidity_pc"]])
    return (predicted,)


@app.cell
def _(data, pd, predicted):
    predicted_df = pd.DataFrame(index=data.index, columns=['predicted'], data=predicted)
    return (predicted_df,)


@app.cell
def _(data, estimator):
    sampled = estimator.sample(X=data[["temperature_degF", "humidity_pc"]], n_samples=50)
    return (sampled,)


@app.cell
def _(data, pd, sampled):
    sampled_df = pd.DataFrame(index=data.index, columns=[f's_{_ix+1:02}' for _ix in range(50)], data=sampled.T)
    return (sampled_df,)


@app.cell
def _(data, plt, predicted_df, reverse, training):
    plt.plot(reverse(predicted_df.loc[training, ['predicted']]), data.loc[training, "elec_total_MW"], marker='.', linewidth=0.2)
    _xlim, _ylim = plt.xlim(), plt.ylim()
    plt.plot([0, 1e5], [0, 1e5], color='red', ls='--')
    plt.xlim(_xlim)
    plt.ylim(_ylim)
    plt.title('training accuracy')
    plt.xlabel('predicted')
    plt.ylabel('actual')
    plt.gcf()
    return


@app.cell
def _(data, holdout, plt, predicted_df, reverse):
    plt.plot(reverse(predicted_df.loc[holdout, ['predicted']]), data.loc[holdout, "elec_total_MW"], marker='.', linewidth=0.2)
    _xlim, _ylim = plt.xlim(), plt.ylim()
    plt.plot([0, 1e5], [0, 1e5], color='red', ls='--')
    plt.xlim(_xlim)
    plt.ylim(_ylim)
    plt.title('test accuracy')
    plt.xlabel('predicted')
    plt.ylabel('actual')
    plt.gcf()
    return


@app.cell
def _(data, holdout, plt, predicted_df, reverse):
    plt.plot(data.loc[holdout, "temperature_degF"], data.loc[holdout, "elec_total_MW"], marker='.', linewidth=0.2, label='actual')
    plt.plot(data.loc[holdout, "temperature_degF"], reverse(predicted_df.loc[holdout, ['predicted']]), marker='.', linewidth=0.2, label='predicted')
    plt.legend()
    plt.gcf()
    return


@app.cell
def _(data, holdout, mo, pd, plt, predicted_df, reverse, sampled_df):
    reverse(sampled_df.loc[holdout]).plot(linewidth=1, color='gray', legend=False, alpha=0.2)
    pd.concat([data.loc[holdout, "elec_total_MW"], reverse(predicted_df.loc[holdout, ['predicted']])], axis=1).plot(ax=plt.gca())
    mo.mpl.interactive(plt.gcf())
    return


@app.cell
def _(data, mo, pd, plt, predicted_df, reverse):
    pd.concat([data["elec_total_MW"], reverse(predicted_df['predicted'])], axis=1).plot()
    mo.mpl.interactive(plt.gcf())
    return


@app.cell
def _(data, holdout, predicted_df, reverse, training):
    training_error = data.loc[training, "elec_total_MW"].dropna().values - reverse(predicted_df.loc[training, 'predicted']).dropna().values
    test_error = data.loc[holdout, "elec_total_MW"].dropna().values - reverse(predicted_df.loc[holdout, 'predicted']).dropna().values
    return test_error, training_error


@app.cell
def _():
    return


if __name__ == "__main__":
    app.run()
