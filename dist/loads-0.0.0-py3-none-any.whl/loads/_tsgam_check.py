import marimo

__generated_with = "0.20.2"
app = marimo.App(width="medium")


@app.cell
def _(mo):
    mo.md(r"""
    # Load Modeling using TS-GAM
    """)
    return


@app.cell
def _(Total, mo):
    # variable selection
    _options = sorted([x for x in Total.COLUMNS if x.endswith("_MW")])
    dependent_ui = mo.ui.dropdown(options=_options,value="elec_total_MW",label="Dependent variable:")

    _options = sorted([x for x in Total.COLUMNS if not x.endswith("_MW")])
    independent_ui = mo.ui.multiselect(options=_options,value=["temperature_degF"],label="Independent variable(s):")

    mo.hstack([independent_ui,dependent_ui])
    return dependent_ui, independent_ui


@app.cell
def _(Cluster, Counties, dependent_ui, mo):
    # counties clustering
    counties = [f"{y} {x}" for x,y in Counties(use_index="RO", selection="WECC")[["ST", "COUNTY"]].values]
    with mo.status.progress_bar(collection=counties,title="Reading county data...",remove_on_exit=True) as _bar:
        cluster = Cluster(counties,dependent_ui.value,progress=lambda x:_bar.update(subtitle=x))
    kmeans = cluster.kmeans(n_clusters=6)
    closest = cluster.closest
    return closest, cluster, counties, kmeans


@app.cell
def _(
    config_ui,
    county_loads,
    data,
    dependent_ui,
    independent_ui,
    mo,
    pd,
    selection,
    test,
    test_estimator,
):
    # main tabs UI
    _data = pd.DataFrame({"test":test},index=["EXCEPTION"]) if isinstance(test,str) else test
    _columns = [x for x in _data.columns if not x.startswith("sample_")]
    mo.ui.tabs(
        {
            "Load data": mo.vstack([selection, county_loads]),
            # "County clustering": mo.vstack([selection, kmeans_ui, clusters]),
            "TSGAM Result": mo.vstack([selection, config_ui, test_estimator]),
            "Input data": mo.vstack(
                [
                    selection,
                    mo.ui.table(
                        data[independent_ui.value+[dependent_ui.value]].round(1),
                        selection=None,
                        page_size=24,
                        text_justify_columns={x:"right" for x in (independent_ui.value+[dependent_ui.value])},
                        show_column_summaries=False,
                        show_data_types=False,
                    ),
                ]
            ),
            "Test data": mo.vstack(
                [
                    selection,
                    mo.ui.table(_data[_columns].round(1), selection=None, page_size=24,
                        text_justify_columns={x:"right" for x in _columns},
                        show_column_summaries=False,
                        show_data_types=False,
                       ),
                ]
            ),
        },
        lazy=True,
    )
    return


@app.cell
def _(mo):
    # clustering UI
    cluster_ui = mo.ui.slider(start=1,stop=10,step=1,debounce=True,value=6,label="Number of k-means clusters:")
    _options = ["Centroids (SV)","Medoids (MW)"]
    show_ui = mo.ui.radio(label="Show",options=_options,inline=True,value=_options[0])
    return cluster_ui, show_ui


@app.cell
def _(cluster, label_ui, mo):
    if label_ui.value:
        svd_ui = mo.ui.slider(start=0,stop=cluster.K[label_ui.value],value=0,label="$U$ column:",debounce=True,show_value=True)
    else:
        svd_ui = mo.ui.slider(start=0,stop=0,value=0,disabled=True,label="$U$ column:")
    return (svd_ui,)


@app.cell
def _(cluster_ui, mo, show_ui, svd_ui):
    kmeans_ui = mo.hstack([cluster_ui,show_ui,svd_ui],justify="start")
    return


@app.cell
def _(closest, cluster, cluster_ui, plt, show_ui):
    # clustering tab plot
    plt.figure(figsize=(10,7))
    plt.clf()
    match show_ui.value:
        case "Centroids (SV)":
            # plt.plot(kmeans.cluster_centers_[label_ui.value].reshape([24,cluster.K[label_ui.value]]))
            plt.gca().set_ylabel("SVD $U_0$")
        case "Medoids (MW)":
            for x in closest:
                plt.plot(cluster.M[x], label=f"{cluster.C[x]} (99%)")
            plt.gca().set_ylabel("Mean normalized loadshape (pu.MW)")
            plt.legend()
        case "_":
            raise ValueError(f"{show_ui.value=} invalid")
    plt.gca().set_xlabel("Hour of day (UTC)")
    plt.title(f"k-Means cluster {show_ui.value.lower()} with $k={cluster_ui.value}$")
    plt.grid()
    clusters = plt.gca()
    return


@app.cell
def _(closest, cluster, counties, label_ui):
    # members of clusters
    members = {n+1:m for n,m in enumerate(cluster.members)}
    members[None] = counties
    default = members[None][0] if label_ui.value is None else cluster.C[closest[label_ui.value-1]]
    return default, members


@app.cell
def _(default, label_ui, members, mo):
    # states UI based on cluster members
    _options = sorted(set([x.split(" ")[-1] for x in members[label_ui.value]]))
    state_ui = mo.ui.dropdown(options=_options,value=default.split(" ")[-1],label="State:")
    return (state_ui,)


@app.cell
def _(cluster, cluster_ui, default, label_ui, members, mo, state_ui):
    # county UI based on cluster members
    if cluster_ui.value is None:
        _counties = [x for x in cluster.C if x.endswith(state_ui.value)]
    else:
        _counties = [x for x in members[label_ui.value] if x.endswith(state_ui.value)]
    county_ui = mo.ui.dropdown(options=sorted(_counties),value=default if default.endswith(state_ui.value) else _counties[0],label="County:")
    return (county_ui,)


@app.cell
def _(Total, closest, cluster, cluster_ui, kmeans, np, pd):
    # save medoids data to file for later processing
    medoids = [cluster.C[x] for x in closest]
    weights = np.zeros(cluster_ui.value)
    for _n, _m in enumerate(kmeans.labels_):
        weights[_m] += cluster.W[_n]
    pd.DataFrame(
        {"county": medoids, "weight": (weights / weights.sum()).round(3)}
        ).to_csv("tsgam_test/medoids.csv", index=False, header=True)
    for _county in medoids:
        Total(_county.split(" ")[-1]," ".join(_county.split(" ")[:-1])).to_csv(f"tsgam_test/{_county}.csv")
    return


@app.cell
def _(cluster_ui, mo):
    # cluster label UI
    label_ui = mo.ui.dropdown(options=range(1,cluster_ui.value+1),label="Cluster:")
    return (label_ui,)


@app.cell
def _(Total, county_ui, state_ui):
    # data from state and county UI
    state = state_ui.value
    county = " ".join(county_ui.value.split(" ")[:-1])
    data = Total(state,county)
    return county, data, state


@app.cell
def _(county_ui, label_ui, mo, state_ui):
    # data selection UI
    selection = mo.hstack([state_ui,county_ui,label_ui],justify="start")
    return (selection,)


@app.cell
def _(county, data, dependent_ui, np, plt, seaborn, state):
    # plot data for selected state and county
    load = np.reshape(data.elec_total_MW.values,(365,24))
    _u,_d,_l = np.linalg.svd(load.T)

    plt.figure(figsize=(16,8))
    plt.suptitle(f"{state} {county}")

    plt.subplot(1,2,2)
    plt.plot(_u[:,0])
    plt.grid()
    plt.gca().set_xlabel("Hour of day (UTC)")
    plt.gca().set_ylabel("U[:,0]")
    plt.title(f"{dependent_ui.value} decomposition $U_0$")

    plt.subplot(1,2,1)
    ax = seaborn.heatmap(load)
    ax.set_ylabel("Day of year")
    ax.set_xlabel("Hour of day (UTC)")
    plt.title(f"{dependent_ui.value} heatmap")

    county_loads = plt.gca()
    return (county_loads,)


@app.cell
def _(mo):
    # harmonics selection ui
    period_options = {"Year":365.2425*24,"Week":7*24,"Day":24}
    year_ui = mo.ui.checkbox(label="Year",value=True)
    week_ui = mo.ui.checkbox(label="Week",value=True)
    day_ui = mo.ui.checkbox(label="Day",value=True)
    return day_ui, period_options, week_ui, year_ui


@app.cell
def _(mo):
    # holdout ui
    holdout_ui = mo.ui.slider(label="Holdout every",steps=[4,5,6,7,8,9,10,11,12],value=8,debounce=True,show_value=True)
    return (holdout_ui,)


@app.cell
def _(day_ui, mo, week_ui, year_ui):
    # harmonics values ui
    year_harmonics_ui = mo.ui.slider(start=1,stop=25,value=3,disabled=not year_ui.value,debounce=True,show_value=True)
    week_harmonics_ui = mo.ui.slider(start=1,stop=25,value=3,disabled=not week_ui.value,debounce=True,show_value=True)
    day_harmonics_ui = mo.ui.slider(start=1,stop=25,value=16,disabled=not day_ui.value,debounce=True,show_value=True)
    return day_harmonics_ui, week_harmonics_ui, year_harmonics_ui


@app.cell
def _(
    day_harmonics_ui,
    day_ui,
    mo,
    week_harmonics_ui,
    week_ui,
    year_harmonics_ui,
    year_ui,
):
    # multi-periodic ui
    multi_periodic_config = mo.hstack(
        [
            mo.md("Periods and harmonics:"),
            mo.hstack([year_ui,year_harmonics_ui],justify="end"),
            mo.hstack([week_ui,week_harmonics_ui],justify="end"),
            mo.hstack([day_ui,day_harmonics_ui],justify="end"),
        ])
    return (multi_periodic_config,)


@app.cell
def _(mo):
    # knots, lags, and AR ui
    n_knots_ui = mo.ui.slider(
        start=1,
        stop=100,
        value=10,
        label="Baseline spline knots:",
        debounce=True,
        show_value=True,
    )
    lags_ui = mo.ui.range_slider(
        start=-24,
        stop=+24,
        value=[-3, 3],
        label="Input lags:",
        show_value=True,
        debounce=True,
    )
    ar_config_ui = mo.ui.slider(start=2,stop=72,value=36,label="AR window:",debounce=True,show_value=True)
    exog_config_ui = mo.hstack(
        [
            n_knots_ui,
            mo.hstack([lags_ui, mo.md("hours")],justify="center"),
            mo.hstack([ar_config_ui, mo.md("hours")],justify="end")
        ]
    )
    return ar_config_ui, exog_config_ui, lags_ui, n_knots_ui


@app.cell
def _(exog_config_ui, mo, multi_periodic_config):
    # configuration ui
    config_ui = mo.vstack([multi_periodic_config,exog_config_ui])
    return (config_ui,)


@app.cell
def _(
    Total,
    ar_config_ui,
    county,
    data,
    day_harmonics_ui,
    day_ui,
    dependent_ui,
    holdout_ui,
    lags_ui,
    mo,
    n_knots_ui,
    period_options,
    state,
    tsgam,
    week_harmonics_ui,
    week_ui,
    year_harmonics_ui,
    year_ui,
):
    # TSGAM holdout test
    mo.stop(
        (data.elec_total_MW == 0).all(),
        mo.md(
            f"**<font color=red>ERROR**: {county} {state} has no total load data</font>"
        ),
    )

    # holdout the last 7 days of each month in the timeseries for testing
    # _holdout = data.index.month != (data.index + dt.timedelta(days=7)).month

    # holdout weeks in the timeseries for testing
    _holdout = ((data.index.dayofyear-1)//7) % holdout_ui.value == holdout_ui.value-1

    # TODO: use bennet holdout selection algorithm
    holdout = data.index[_holdout]
    training = data.index[~_holdout]

    def get_periods():
        return [y for x,y in [
            (year_ui,period_options["Year"]),
            (week_ui,period_options["Week"]),
            (day_ui,period_options["Day"])] if x.value]
    def get_harmonics():
        return [y.value for x,y in [
            (year_ui,year_harmonics_ui),
            (week_ui,week_harmonics_ui),
            (day_ui,day_harmonics_ui)] if x.value]

    # run test
    Total.TSGAM_CONFIG = tsgam.TsgamEstimatorConfig(
        multi_periodic_config=tsgam.TsgamMultiPeriodicConfig(
            num_harmonics=get_harmonics(), 
            periods=get_periods()
        ),
        exog_config=[
            tsgam.TsgamSplineConfig(
                knots=[],  # Empty list means knots will be auto-generated from data
                n_knots=n_knots_ui.value,  # Number of knots to generate
                lags=range(lags_ui.value[0],lags_ui.value[1]+1),
                reg_weight=1e-4,  # Regularization weight for coefficients
                diff_reg_weight=1.0,  # Regularization weight for differences between lags
            )
        ],
        ar_config=tsgam.TsgamArConfig(lags=list(range(1, ar_config_ui.value))),
        solver_config=tsgam.TsgamSolverConfig(solver="CLARABEL", verbose=False),
        random_state=None,
        debug=False,
    )

    try:
        test = data.test(state, county, holdout, Y=dependent_ui.value,n_samples=100).rename(
            {dependent_ui.value: "actual"}, axis=1
        )
        test["training"] = test["actual"]
        test["holdout"] = test["actual"]
        test.loc[holdout, "training"] = float("nan")
        test.loc[training, "holdout"] = float("nan")
    except Exception as err:
        raise
        test = str(err)
    return holdout, test


@app.cell
def _(holdout_ui, mo):
    plot_ui = mo.ui.slider(
        start=1,
        stop=52,
        value=holdout_ui.value,
        debounce=True,
        show_value=True,
        label="Plot week:",
    )
    return (plot_ui,)


@app.cell
def _(
    Rectangle,
    county,
    dt,
    holdout,
    holdout_ui,
    mo,
    np,
    plot_ui,
    plt,
    state,
    test,
):
    # holdout test evaluation
    if not isinstance(test, str):
        residual = (test["predict"] - test["holdout"]).dropna()
        rmse = np.sqrt(np.mean(residual**2))
        mean = test["holdout"].dropna().mean()
        percent_rmse = (
            rmse / mean * 100 if mean != 0 else (0.0 if rmse == 0 else np.inf)
        )
        fig = plt.figure(figsize=(10,7))
        _dtrange = np.s_[(plot_ui.value-1) * 24 * 7: (plot_ui.value) * 24 * 7 + 1]
        plt.plot(test.iloc[_dtrange][[x for x in test.columns if x.startswith("sample")]],color="grey",alpha=0.2,label="Actual")
        _ax = test.iloc[_dtrange][
            ["actual", "predict"]
        ].plot(ax=plt.gca(),
            grid=True,
            title=f"{county} {state} Holdout Test Result (RMSE={rmse:.1f} MW / {percent_rmse:.2f}%)",
            xlabel="Date/Time (UTC)",
            ylabel="Load (MW)",
        )
        _max = test["actual"].max()
        for _x in holdout:
            _ax.add_patch(Rectangle((_x.to_datetime64(),0),dt.timedelta(hours=1),_max,facecolor="lightgrey",alpha=0.2))
        test_estimator = mo.vstack(
            [
                mo.hstack(
                    [
                        plot_ui,
                        mo.hstack([holdout_ui, mo.md("weeks")], justify="end"),
                    ]
                ),
                _ax.figure,
            ]
        )
    else:
        test_estimator = f"EXCEPTION: {test}"
    return (test_estimator,)


@app.cell
def _():
    # modules
    import marimo as mo
    import numpy as np
    import pandas as pd
    import datetime as dt
    import matplotlib.pyplot as plt
    import seaborn
    from loads import Total
    from fips import Counties

    return Counties, Total, dt, mo, np, pd, plt, seaborn


@app.cell
def _():
    from loads import Cluster

    return (Cluster,)


@app.cell
def _():
    from matplotlib.patches import Rectangle

    return (Rectangle,)


@app.cell
def _(pd):
    import tsgam_estimator as tsgam
    pd.options.display.width = None
    pd.options.display.max_columns = None
    pd.options.display.max_rows = 100
    return (tsgam,)


if __name__ == "__main__":
    app.run()
